using System;
using System;
namespace PracticalTask.Models
{
    public abstract class BaseProduct
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double CostPrice { get; set; }
        public int Qty {get;set;}
        public double SalesPrice { get; private set; }
        public virtual void CalculateSalesPrice()
        {
            double pricewithmargin = CostPrice * 1.225;
            double pricewithWat = pricewithmargin * 1.10;
            SalesPrice = Math.Round(pricewithWat, 2);
        }
    }
}