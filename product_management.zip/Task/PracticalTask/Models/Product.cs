namespace PracticalTask.Models
{
    public class Product:BaseProduct
    {
        public override void CalculateSalesPrice()
        {
            base.CalculateSalesPrice();
        }
    }
}