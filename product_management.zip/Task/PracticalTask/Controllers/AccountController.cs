using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using System.Collections.Generic;
using PracticalTask.Models;
using System.Linq;

namespace PracticalTask.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(User model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var user = _context.User.FirstOrDefault(u => u.Username == model.Username && u.Password == model.Password);
                    if (user != null)
                    {
                        var claims = new List<Claim> { new Claim(ClaimTypes.Name, user.Username) };
                        var identity = new ClaimsIdentity(claims, "UserAuth");
                        HttpContext.SignInAsync("UserAuth", new ClaimsPrincipal(identity));
                        return RedirectToAction("Index", "Product");
                    }
                }
                catch
                {
                    // Fallback to hardcoded login if database table doesn't exist
                    if (model.Username == "admin" && model.Password == "123")
                    {
                        var claims = new List<Claim> { new Claim(ClaimTypes.Name, model.Username) };
                        var identity = new ClaimsIdentity(claims, "UserAuth");
                        HttpContext.SignInAsync("UserAuth", new ClaimsPrincipal(identity));
                        return RedirectToAction("Index", "Product");
                    }
                }
            }

            ViewBag.Error = "Invalid Login";
            return View(model);
        }

        public IActionResult Logout()
        {
            HttpContext.SignOutAsync("UserAuth");
            return RedirectToAction("Index", "Product");
        }
    }
}
