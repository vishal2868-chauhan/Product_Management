using Microsoft.AspNetCore.Mvc;
using PracticalTask.Models;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
namespace PracticalTask.Controllers
{
    public class ProductController   : Controller
    {
        private readonly AppDbContext _context;
        public ProductController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var products = _context.Product.ToList();
            return View(products);
        }
        [Authorize]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [Authorize]
        public IActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                product.CalculateSalesPrice();
                _context.Product.Add(product);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(product);
        }
        [Authorize]
        public IActionResult Edit(int id)
        {
            var product = _context.Product.Find(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }
        [HttpPost]
        [Authorize]
        public IActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                product.CalculateSalesPrice();
                _context.Product.Update(product);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(product);
        }
        [Authorize]
        public IActionResult Delete(int id)
        {
            var product = _context.Product.Find(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }
        [HttpPost, ActionName("Delete")]
        [Authorize]
        public IActionResult DeleteConfirmed(int id)
        {
            var product = _context.Product.Find(id);
            if (product == null)
            {
                return NotFound();
            }
            _context.Product.Remove(product);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}